from flask import Flask, request
from flask.templating import render_template
import logging

app = Flask(__name__)

logging.basicConfig(filename='record.log', level=logging.DEBUG, format=f'%(asctime)s %(levelname)s %(name)s %(threadName)s : %(message)s)')

@app.route('/')
def homeContent():
    app.logger.info('Index page loaded fine!')
    app.logger.warning('This seems to be a problem!')
    return render_template('index.html')

@app.route('/contact')
def contactContent():
    return render_template('contact.html')

@app.route('/about')
def aboutContent():
    return render_template('about.html')

@app.route('/success', methods=["GET"])
def successMessage():
    if request.method=="POST":
        username = request.form.get('username')
        userphone = request.form.get('userphone')
        userage = request.form.get('userage')
    return render_template('success.html', form_data = username+userphone+userage)

if(__name__ == "__main__"):
    app.run(debug=True)